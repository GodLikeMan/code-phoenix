/*
*	Fake date input
*	for test only
*/

use ampro;

INSERT INTO product(sku,cost)
VALUES
('test1',5566);


INSERT INTO seller(name,sell_platform)
VALUES
('sokie tech','amazon'),
('test_account','ebay');

INSERT INTO product_price(sku,seller_id,price)
VALUES
('test1',1,77.88),
('test1',2,86.86);

INSERT INTO package_volume(sku,p_type,p_length,p_width,p_height,p_weight)
VALUES
('test1','木箱',180,55,8,9.56),
('test1','紙箱',155,55,5,5.56);
